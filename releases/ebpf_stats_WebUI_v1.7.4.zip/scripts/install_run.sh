#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
chown -R root:root "$MODDIR"
chmod 755 "$MODDIR" "$MODDIR/scripts" "$MODDIR/service.sh" "$MODDIR/uninstall.sh"
chmod 755 "$MODDIR/scripts"/*.sh
mkdir -p "$MODDIR/run" "$MODDIR/ebpf_statistics"

# 停旧
if [ -f "$MODDIR/run/daemon.pid" ]; then
  kill "$(cat "$MODDIR/run/daemon.pid")" 2>/dev/null
  sleep 0.5
fi
sh "$MODDIR/scripts/cleanup.sh" es_

export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
sleep 2

echo "PID=$(cat "$MODDIR/run/daemon.pid")"
echo "--- daemon.log ---"
cat "$MODDIR/run/daemon.log" 2>/dev/null
echo "--- scope ---"
cat "$MODDIR/scope.list"
echo "--- kprobe ---"
cat /sys/kernel/tracing/kprobe_events 2>/dev/null | head -20
echo "--- run ---"
ls -la "$MODDIR/run/"
echo "--- ps ---"
ps -A 2>/dev/null | grep -i daemon | head -5
# 确认进程在
pid=$(cat "$MODDIR/run/daemon.pid")
if [ -d "/proc/$pid" ]; then
  echo "daemon ALIVE $pid"
else
  echo "daemon DEAD"
fi
