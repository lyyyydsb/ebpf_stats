#!/system/bin/sh
set -e
MODDIR=/data/adb/modules/ebpf_stats
SRC=/data/local/tmp

cp -f "$SRC/daemon.sh" "$MODDIR/scripts/daemon.sh"
cp -f "$SRC/ctl.sh" "$MODDIR/scripts/ctl.sh"
cp -f "$SRC/check_status.sh" "$MODDIR/scripts/check_status.sh"
chmod 755 "$MODDIR/scripts/"*.sh
# 去 CRLF
for f in "$MODDIR/scripts/"*.sh "$MODDIR/service.sh" "$MODDIR/uninstall.sh"; do
  [ -f "$f" ] || continue
  tr -d '\r' < "$f" > "$f.tmp" && mv "$f.tmp" "$f"
  chmod 755 "$f"
done

chown -R root:root "$MODDIR"
mkdir -p "$MODDIR/run" "$MODDIR/ebpf_statistics"

# 停旧
if [ -f "$MODDIR/run/daemon.pid" ]; then
  kill "$(cat "$MODDIR/run/daemon.pid")" 2>/dev/null || true
  sleep 0.5
fi
sh "$MODDIR/scripts/cleanup.sh" es_ || true

export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
sleep 2
sh "$MODDIR/scripts/check_status.sh"
