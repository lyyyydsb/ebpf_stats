#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
cp -f /data/local/tmp/daemon.sh "$MODDIR/scripts/daemon.sh"
cp -f /data/local/tmp/probe.sh "$MODDIR/scripts/probe.sh"
for f in daemon.sh probe.sh; do
  tr -d '\r' < "$MODDIR/scripts/$f" > "$MODDIR/scripts/$f.t"
  mv "$MODDIR/scripts/$f.t" "$MODDIR/scripts/$f"
  chmod 755 "$MODDIR/scripts/$f"
done

# 确保 scope
grep -q 'com.tencent.tmgp.cod' "$MODDIR/scope.list" 2>/dev/null || echo 'com.tencent.tmgp.cod:0' >> "$MODDIR/scope.list"

for p in $(ps -A 2>/dev/null | grep 'scripts/daemon.sh' | awk '{print $2}'); do
  kill "$p" 2>/dev/null
done
sleep 1
sh "$MODDIR/scripts/cleanup.sh" es_ 2>/dev/null

export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
echo "daemon $(cat "$MODDIR/run/daemon.pid")"

sleep 6
echo "=== log ==="
tail -25 "$MODDIR/run/daemon.log"
echo "=== discover ==="
cat "$MODDIR/run/discover.tmp" 2>/dev/null
echo "=== pidmap ==="
cat "$MODDIR/run/pidmap" 2>/dev/null
echo "=== sess ==="
cat "$MODDIR/run"/sess_* 2>/dev/null
echo "=== kprobe ==="
cat /sys/kernel/tracing/kprobe_events
echo "tracing=$(cat /sys/kernel/tracing/tracing_on) pids=$(wc -l < /sys/kernel/tracing/set_event_pid)"
echo "open_en=$(cat /sys/kernel/tracing/events/kprobes/es_open/enable 2>/dev/null)"
echo "=== wait 8s for events ==="
sleep 8
sess=$(grep '^sess=' "$MODDIR/run"/sess_* 2>/dev/null | head -1 | cut -d= -f2-)
echo "sess=$sess"
if [ -n "$sess" ]; then
  echo "events_counter=$(grep '^events=' "$MODDIR/run"/sess_* | head -1)"
  echo "log_lines=$(wc -l < "$sess/events.log")"
  echo "--- last 30 events ---"
  tail -30 "$sess/events.log"
fi
echo "=== trace sample ---"
head -c 1500 /sys/kernel/tracing/trace 2>/dev/null
echo ""
