#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
for f in daemon.sh ctl.sh; do
  cp -f /data/local/tmp/$f "$MODDIR/scripts/$f"
  tr -d '\r' < "$MODDIR/scripts/$f" > "$MODDIR/scripts/$f.t"
  mv "$MODDIR/scripts/$f.t" "$MODDIR/scripts/$f"
  chmod 755 "$MODDIR/scripts/$f"
done
cp -f /data/local/tmp/service.sh "$MODDIR/service.sh"
tr -d '\r' < "$MODDIR/service.sh" > "$MODDIR/service.sh.t"
mv "$MODDIR/service.sh.t" "$MODDIR/service.sh"
chmod 755 "$MODDIR/service.sh"

# 硬杀全部
for p in $(ps -A 2>/dev/null | grep 'ebpf_stats' | awk '{print $2}'); do
  kill -9 "$p" 2>/dev/null
done
sleep 1
sh "$MODDIR/scripts/cleanup.sh" es_ 2>/dev/null
rm -rf "$MODDIR/run/daemon.lock"
: > "$MODDIR/run/daemon.log"

export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
sleep 2
echo "=== should be EXACTLY 1 daemon ==="
ps -A -o PID,PCPU,ARGS 2>/dev/null | grep 'ebpf_stats/scripts/daemon' | grep -v grep
echo "=== log ==="
cat "$MODDIR/run/daemon.log"
echo "=== lock ==="
ls -la "$MODDIR/run/daemon.lock" 2>/dev/null
cat "$MODDIR/run/daemon.lock/pid" 2>/dev/null
echo ""
# 再 start 一次应被拒绝
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
sleep 1
echo "=== after double-start (still 1?) ==="
ps -A -o PID,PCPU,ARGS 2>/dev/null | grep 'ebpf_stats/scripts/daemon' | grep -v grep
cat "$MODDIR/run/daemon.log"
