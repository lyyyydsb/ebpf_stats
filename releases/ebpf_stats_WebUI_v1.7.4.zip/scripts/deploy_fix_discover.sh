#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
cp -f /data/local/tmp/daemon.sh "$MODDIR/scripts/daemon.sh"
tr -d '\r' < "$MODDIR/scripts/daemon.sh" > "$MODDIR/scripts/daemon.sh.t"
mv "$MODDIR/scripts/daemon.sh.t" "$MODDIR/scripts/daemon.sh"
chmod 755 "$MODDIR/scripts/daemon.sh"

# 确保 scope 正确
if ! grep -q 'com.tencent.tmgp.cod' "$MODDIR/scope.list" 2>/dev/null; then
  echo 'com.tencent.tmgp.cod:0' >> "$MODDIR/scope.list"
fi

for p in $(ps -A 2>/dev/null | grep 'scripts/daemon.sh' | awk '{print $2}'); do
  kill "$p" 2>/dev/null
done
sleep 0.8
sh "$MODDIR/scripts/cleanup.sh" es_ 2>/dev/null

export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
echo "started $(cat "$MODDIR/run/daemon.pid")"

# 等两轮 poll
sleep 5
echo "=== log ==="
tail -20 "$MODDIR/run/daemon.log"
echo "=== scope_rules ==="
cat "$MODDIR/run/scope_rules"
echo "=== discover.tmp ==="
cat "$MODDIR/run/discover.tmp" 2>/dev/null
echo "=== pidmap ==="
cat "$MODDIR/run/pidmap" 2>/dev/null
echo "=== active_keys ==="
cat "$MODDIR/run/active_keys" 2>/dev/null
echo "=== sess ==="
ls "$MODDIR/run"/sess_* 2>/dev/null
for s in "$MODDIR/run"/sess_*; do
  [ -f "$s" ] && echo "-- $s" && cat "$s"
done
echo "=== stats ==="
ls -la "$MODDIR/ebpf_statistics" 2>/dev/null
echo "=== kprobe ==="
cat /sys/kernel/tracing/kprobe_events 2>/dev/null
echo "tracing_on=$(cat /sys/kernel/tracing/tracing_on 2>/dev/null)"
