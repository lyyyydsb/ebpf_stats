#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
cp -f /data/local/tmp/daemon.sh "$MODDIR/scripts/daemon.sh"
cp -f /data/local/tmp/config.prop "$MODDIR/config.prop"
tr -d '\r' < "$MODDIR/scripts/daemon.sh" > "$MODDIR/scripts/daemon.sh.t" && mv "$MODDIR/scripts/daemon.sh.t" "$MODDIR/scripts/daemon.sh"
tr -d '\r' < "$MODDIR/config.prop" > "$MODDIR/config.prop.t" && mv "$MODDIR/config.prop.t" "$MODDIR/config.prop"
chmod 755 "$MODDIR/scripts/daemon.sh"
if [ -f "$MODDIR/run/daemon.pid" ]; then
  kill "$(cat "$MODDIR/run/daemon.pid")" 2>/dev/null
  sleep 0.5
fi
export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
sleep 1
tail -5 "$MODDIR/run/daemon.log"
grep ALLOWED "$MODDIR/config.prop"
pid=$(cat "$MODDIR/run/daemon.pid")
[ -d "/proc/$pid" ] && echo "daemon YES $pid" || echo "daemon NO"
