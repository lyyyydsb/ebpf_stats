#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
cp -f /data/local/tmp/daemon.sh "$MODDIR/scripts/daemon.sh"
cp -f /data/local/tmp/ctl.sh "$MODDIR/scripts/ctl.sh"
for f in daemon.sh ctl.sh; do
  tr -d '\r' < "$MODDIR/scripts/$f" > "$MODDIR/scripts/$f.t"
  mv "$MODDIR/scripts/$f.t" "$MODDIR/scripts/$f"
  chmod 755 "$MODDIR/scripts/$f"
done
# restart daemon
for p in $(ls /proc | grep '^[0-9]*$'); do
  [ -r /proc/$p/cmdline ] || continue
  cmd=$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)
  case "$cmd" in *ebpf_stats/scripts/daemon.sh*) kill -9 "$p" 2>/dev/null ;; esac
done
sleep 1
rm -rf "$MODDIR/run/daemon.lock"
export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" </dev/null >/dev/null 2>&1 &
sleep 2
echo "daemon:"; ps -A -o PID,ARGS 2>/dev/null | grep 'ebpf_stats/scripts/daemon' | grep -v grep
echo "log:"; sed -n '$p' "$MODDIR/run/daemon.log"
