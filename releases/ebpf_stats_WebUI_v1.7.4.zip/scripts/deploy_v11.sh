#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
SRC=/data/local/tmp

cp -f "$SRC/daemon.sh" "$MODDIR/scripts/daemon.sh"
cp -f "$SRC/probe.sh" "$MODDIR/scripts/probe.sh"
cp -f "$SRC/cleanup.sh" "$MODDIR/scripts/cleanup.sh"
cp -f "$SRC/config.prop" "$MODDIR/config.prop"
cp -f "$SRC/module.prop" "$MODDIR/module.prop"

for f in "$MODDIR/scripts/"*.sh; do
  tr -d '\r' < "$f" > "$f.t" && mv "$f.t" "$f"
  chmod 755 "$f"
done
tr -d '\r' < "$MODDIR/config.prop" > "$MODDIR/config.prop.t" && mv "$MODDIR/config.prop.t" "$MODDIR/config.prop"

if [ -f "$MODDIR/run/daemon.pid" ]; then
  kill "$(cat "$MODDIR/run/daemon.pid")" 2>/dev/null
  sleep 0.5
fi
sh "$MODDIR/scripts/cleanup.sh" es_
sleep 0.3

export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
sleep 1

echo "PID=$(cat "$MODDIR/run/daemon.pid")"
echo "=== daemon.log ==="
cat "$MODDIR/run/daemon.log"
echo "=== kprobe (应为空，等 App 启动才挂) ==="
cat /sys/kernel/tracing/kprobe_events 2>/dev/null
echo "=== config death ==="
grep DEATH "$MODDIR/config.prop"
# 快速自测探针能否注册
export TRACE_DIR=/sys/kernel/tracing PROBE_PREFIX=es_ ENABLE_CONN=1 ENABLE_DEATH=1
# shellcheck disable=SC1091
. "$MODDIR/scripts/probe.sh"
ok=$(probe_setup)
echo "probe_setup ok=$ok"
cat /sys/kernel/tracing/kprobe_events
probe_rm
echo "done, daemon alive?"
pid=$(cat "$MODDIR/run/daemon.pid")
[ -d "/proc/$pid" ] && echo YES "$pid" || echo NO
