#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
cp -f /data/local/tmp/daemon.sh "$MODDIR/scripts/daemon.sh"
cp -f /data/local/tmp/ctl.sh "$MODDIR/scripts/ctl.sh"
cp -f /data/local/tmp/config.prop "$MODDIR/config.prop"
cp -f /data/local/tmp/scope.list "$MODDIR/scope.list"
for f in "$MODDIR/scripts/daemon.sh" "$MODDIR/scripts/ctl.sh"; do
  tr -d '\r' < "$f" > "$f.t" && mv "$f.t" "$f"
  chmod 755 "$f"
done
tr -d '\r' < "$MODDIR/config.prop" > "$MODDIR/config.prop.t" && mv "$MODDIR/config.prop.t" "$MODDIR/config.prop"
tr -d '\r' < "$MODDIR/scope.list" > "$MODDIR/scope.list.t" && mv "$MODDIR/scope.list.t" "$MODDIR/scope.list"

for p in $(ps -A 2>/dev/null | grep 'scripts/daemon.sh' | awk '{print $2}'); do
  kill "$p" 2>/dev/null
done
sleep 0.5
export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
sleep 1
echo "=== scope.list ==="
cat "$MODDIR/scope.list"
echo "=== log ==="
tail -3 "$MODDIR/run/daemon.log"
echo "pid=$(cat "$MODDIR/run/daemon.pid")"
