#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
cp -f /data/local/tmp/daemon.sh "$MODDIR/scripts/daemon.sh"
cp -f /data/local/tmp/config.prop "$MODDIR/config.prop"
tr -d '\r' < "$MODDIR/scripts/daemon.sh" > "$MODDIR/scripts/daemon.sh.t" && mv "$MODDIR/scripts/daemon.sh.t" "$MODDIR/scripts/daemon.sh"
tr -d '\r' < "$MODDIR/config.prop" > "$MODDIR/config.prop.t" && mv "$MODDIR/config.prop.t" "$MODDIR/config.prop"
chmod 755 "$MODDIR/scripts/daemon.sh"

# 杀掉所有相关
for p in $(ps -A 2>/dev/null | grep 'ebpf_stats' | awk '{print $2}'); do
  kill "$p" 2>/dev/null
done
sleep 1
sh "$MODDIR/scripts/cleanup.sh" es_ 2>/dev/null

# 清爆掉的 log
: > "$MODDIR/run/daemon.log"

export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
sleep 2
echo "daemon=$(cat "$MODDIR/run/daemon.pid") alive=$([ -d /proc/$(cat "$MODDIR/run/daemon.pid") ] && echo Y || echo N)"
echo "cpu sample:"
ps -A -o PID,PCPU,ARGS 2>/dev/null | grep ebpf | sed -n '1,5p'
echo "log:"
sed -n '1,10p' "$MODDIR/run/daemon.log"
echo "taobao session exists:"
ls -la "$MODDIR/ebpf_statistics/com.taobao.taobao_u0/" 2>/dev/null
