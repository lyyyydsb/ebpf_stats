#!/system/bin/sh
MODDIR=/data/adb/modules/ebpf_stats
# 杀掉所有旧 daemon
for p in $(ps -A 2>/dev/null | grep 'scripts/daemon.sh' | awk '{print $2}'); do
  kill "$p" 2>/dev/null
done
sleep 0.5
sh "$MODDIR/scripts/cleanup.sh" es_ 2>/dev/null
mkdir -p "$MODDIR/run"
export MODDIR
nohup sh "$MODDIR/scripts/daemon.sh" >/dev/null 2>&1 &
echo $! > "$MODDIR/run/daemon.pid"
sleep 1
echo "pidfile=$(cat "$MODDIR/run/daemon.pid")"
tail -3 "$MODDIR/run/daemon.log"
ps -A 2>/dev/null | grep daemon.sh | head -5
