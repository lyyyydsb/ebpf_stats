# eBPF Stats + EnvProbe v1.5.3

## 刷入后

1. 重启
2. 编辑 `/data/adb/modules/ebpf_stats/scope.list` 加包名
3. 打开目标 App → 杀后台 → 自动出汇总
4. 打开 **EnvProbe** 点扫描 → 按包查看全部外部路径的可见性

## 目录

```
/data/adb/modules/ebpf_stats/
  scope.list / config.prop / scripts/
  ebpf_statistics/<包>_u0/session_*/
    events_risk.log   # 外部路径事件（兼容旧文件名）
    biz_counts.txt    # 自身私有路径合并计数
    paths_external.txt
    summary.txt
    paths_risk.txt
  apk/EnvProbe.apk
```

EnvProbe 数据：`/data/data/com.envprobe/files/from_module/by_pkg/`

## 命令

```sh
su 0 sh /data/adb/modules/ebpf_stats/scripts/ctl.sh status
su 0 sh /data/adb/modules/ebpf_stats/scripts/ctl.sh push
su 0 sh /data/adb/modules/ebpf_stats/scripts/ctl.sh restart
```

## 路径状态含义

模块记录目标 App 实际访问的路径，排除目标自身 `/proc` 和私有目录后生成
`paths_external.txt`。EnvProbe 对每条路径以普通 App 身份执行 `exists()`：

- `可见`：`exists=true`
- `不可见`：`exists=false`
- `环境特征`：可见路径同时命中 su/Magisk/KSU/LSPosed 等特征词
